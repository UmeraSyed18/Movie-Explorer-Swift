//
//  MovieExplorerTests.swift
//  MovieExplorerTests
//
//  Created by eman sohail on 16/01/2025.
//

import Testing
@testable import MovieExplorer

struct MovieExplorerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
