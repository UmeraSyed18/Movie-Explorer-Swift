//
//  MovieExplorerApp.swift
//  MovieExplorer
//
//  Created by eman sohail on 16/01/2025.
//

import SwiftUI

@main
struct MovieExplorerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
